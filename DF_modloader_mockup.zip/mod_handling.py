import os

object_types = {"BODY_DETAIL_PLAN": ["BODY_DETAIL_PLAN"],
                "BODY": ["BODY",
                         "BODYGLOSS"],
                "BUILDING": ["BUILDING_WORKSHOP"],
                "CREATURE_VARIATION": ["CREATURE_VARIATION"],
                "CREATURE": ["CREATURE"],
                "DESCRIPTOR_COLOR": ["COLOR"],
                "DESCRIPTOR_PATTERN": ["COLOR_PATTERN"],
                "DESCRIPTOR_SHAPE": ["SHAPE"],
                "ENTITY": ["ENTITY"],
                "INORGANIC": ["INORGANIC"],
                "INTERACTION": ["INTERACTION"],
                "ITEM": ["ITEM_AMMO",
                         "ITEM_ARMOR",
                         "ITEM_FOOD",
                         "ITEM_GLOVES",
                         "ITEM_HELM",
                         "ITEM_INSTRUMENT",
                         "ITEM_PANTS",
                         "ITEM_SHIELD",
                         "ITEM_SIEGEAMMO",
                         "ITEM_TOOL",
                         "ITEM_TOY",
                         "ITEM_TRAPCOMP",
                         "ITEM_WEAPON"],
                "LANGUAGE": ["TRANSLATION",
                             "SYMBOL",
                             "WORD"],
                "MATERIAL_TEMPLATE": ["MATERIAL_TEMPLATE"],
                "PLANT": ["PLANT"],
                "REACTION": ["REACTION"],
                "TISSUE_TEMPLATE": ["TISSUE_TEMPLATE"]}

object_dicts = {object_type: {}
                for object_type in
                # this just flattens the list of object_types.values()
                [val for sublist in object_types.values() for val in sublist]}
object_lists = {object_type: []
                for object_type in
                # this just flattens the list of object_types.values()
                [val for sublist in object_types.values() for val in sublist]}


class Mod:

    def __init__(self, name, raw_path):
        self.name = name
        self.raw_path = raw_path
        self.file_names = [filename for filename in os.listdir(raw_path) if filename.endswith(".txt")]


# ======================================================================================================================

def split_file_into_tokens(file):
    # does what it sounds like, splits a text file into tokens, discarding comments along the way
    token_list = []

    file_string = "".join(list(line for line in file))
    reading_mode = "comments"
    token = ""
    args = ""
    # just goes through each of the characters in the file, switching "reading_mode" when necessary.
    for c in file_string:
        if reading_mode == "comments":
            if c == "[":
                reading_mode = "token"
        elif reading_mode == "token":
            if c == ":":
                reading_mode = "args"
            elif c == "]":
                token_list.append([token])
                token = ""
                reading_mode = "comments"
            else:
                token += c
        elif reading_mode == "args":
            if c == "]":
                token_list.append([token] + args.split(":"))
                token = ""
                args = ""
                reading_mode = "comments"
            else:
                args += c

    return token_list


def read_and_apply_mod(mod):
    global top_level_objects

    # goes through each file of the mod
    for i in range(len(mod.file_names)):
        # opens the file and splits it into tokens
        print("reading file " + str(i + 1) + "/" + str(len(mod.file_names)), mod.file_names[i])
        filename = mod.file_names[i]
        rawfile = open(mod.raw_path + "/" + filename, "r", encoding="latin1")
        rawfile_tokens = split_file_into_tokens(rawfile)

        # initially it doesn't know what object types to expect
        # and it has to know, because e.g. "COLOR" is both an object type and a common token elsewhere.
        pos_object_types = []

        mode = "NONE"
        object_type = None
        object_id = None
        object_tokens = []

        # goes through all tokens
        for j in range(len(rawfile_tokens)):
            token = rawfile_tokens[j]

            # the "OBJECT" token tells it what object types to expect
            if token[0] == "OBJECT":
                pos_object_types = object_types[token[1]]

            # new object, the traditional/vanilla way
            elif token[0] in pos_object_types:
                object_type = token[0]
                object_id = token[1]

            # new object, the modloader-specific way
            elif token[0] == "NEW_OBJECT":
                object_type = token[1]
                object_id = token[2]

            elif token[0] == "EDIT_OBJECT":
                object_type = token[1]
                object_id = token[2]

            elif token[0] == "REMOVE_OBJECT":
                object_type = token[1]
                object_id = token[2]
                mode = "NONE"

            else:
                if mode in ["READ", "EDIT"]:
                    object_tokens.append(token)
